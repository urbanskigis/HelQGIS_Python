from osgeo import ogr

driver=ogr.GetDriverByName('ESRI shapefile')

# parametry
ff=r"C:\JACEK2\QGISHEL18\Hel18\dzien5\dane5\Linie.shp"

p_text=r"C:\JACEK2\QGISHEL18\Hel18\dzien5\dane5\xy_werteksy.txt"


dataSource=driver.Open(ff,0)  # czytanie i pisanie

vlayer=dataSource.GetLayer()
#print vlayer.GetGeomType()
numFeature=vlayer.GetFeatureCount()
#print numFeature
file=open(p_text,"w")
for i in range (0, numFeature):
    feature=vlayer.GetFeature(i)
    
    geometry=feature.GetGeometryRef()
    nwtx=geometry.GetPointCount()

    for j in range(0,nwtx):
        x=geometry.GetX(j)
        y=geometry.GetY(j)

        ss= str(i)+','+str( j)+','+str( round(x,2))+','+str(round(y,2))+'\n'
        file.write(ss)
file.close()        
feature.Destroy()

